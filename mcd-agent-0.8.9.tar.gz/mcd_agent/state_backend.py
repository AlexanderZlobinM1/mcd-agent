from __future__ import annotations

from datetime import datetime, timezone
import json
import os
import re
from typing import Any

import pymysql
from pymysql.cursors import DictCursor

from mcd_agent.config import AgentConfig
from mcd_agent.host_identity import resolve_agent_identity


_SCHEMA_READY: set[str] = set()
_DB_READY: set[str] = set()
_LOCAL_SOCKET_CANDIDATES: tuple[str, ...] = (
    "/var/run/mysqld/mysqld.sock",
    "/run/mysqld/mysqld.sock",
)


def _mask_scalar(value: Any) -> Any:
    if value is None:
        return None
    raw = str(value)
    if not raw:
        return ""
    return "***"


def _sanitize_snapshot_payload(raw: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}

    def walk(value: Any, parent: str = "", key: str = "") -> Any:
        if isinstance(value, dict):
            nested: dict[str, Any] = {}
            for k, v in value.items():
                sk = str(k)
                lk = sk.lower()
                if parent == "config_state" and lk == "toml":
                    nested[sk] = "[omitted]"
                    continue
                if lk in {"password", "token", "secret"} or lk.endswith("_password") or lk.endswith("_token"):
                    nested[sk] = _mask_scalar(v)
                    continue
                nested[sk] = walk(v, parent=sk, key=sk)
            return nested
        if isinstance(value, list):
            return [walk(v, parent=parent, key=key) for v in value]
        return value

    for k, v in raw.items():
        out[str(k)] = walk(v, parent=str(k), key=str(k))
    return out


def normalized_state_backend(cfg: AgentConfig) -> str:
    raw = str(getattr(cfg, "state_backend", "sqlite") or "sqlite").strip().lower()
    if raw in {"mysql", "mariadb", "mysql_hybrid", "hybrid"}:
        return "mysql_hybrid"
    return "sqlite"


def _is_local_mysql_host(host: str | None) -> bool:
    raw = str(host or "").strip().lower()
    return raw in {"", "localhost", "127.0.0.1", "::1"}


def _resolved_mysql_unix_socket(cfg: AgentConfig, *, host: str | None, password: str | None) -> str | None:
    explicit = str(getattr(cfg, "state_mysql_unix_socket", "") or "").strip()
    if explicit:
        return explicit
    if not _is_local_mysql_host(host):
        return None
    if str(password or "") != "":
        return None
    for cand in _LOCAL_SOCKET_CANDIDATES:
        if os.path.exists(cand):
            return cand
    return None


def _safe_db_name(raw: str | None) -> str:
    name = str(raw or "").strip() or "mcd_state"
    if not re.match(r"^[A-Za-z0-9_]+$", name):
        raise ValueError(f"unsafe state mysql database name: {name!r}")
    return name


def _state_database_name(cfg: AgentConfig) -> str:
    return _safe_db_name(getattr(cfg, "state_mysql_database", ""))


def mysql_state_enabled(cfg: AgentConfig) -> bool:
    if normalized_state_backend(cfg) != "mysql_hybrid":
        return False
    host = str(getattr(cfg, "state_mysql_host", "") or "").strip()
    pwd = str(getattr(cfg, "state_mysql_password", "") or "")
    sock = _resolved_mysql_unix_socket(cfg, host=host, password=pwd)
    return bool(
        (host or sock)
        and str(getattr(cfg, "state_mysql_user", "") or "").strip()
    )


def _safe_prefix(raw: str | None) -> str:
    prefix = str(raw or "mcd_").strip() or "mcd_"
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", prefix):
        raise ValueError(f"unsafe state mysql table prefix: {prefix!r}")
    if not prefix.endswith("_"):
        prefix = prefix + "_"
    return prefix


def _host_name_for_state(cfg: AgentConfig) -> str:
    ident = resolve_agent_identity(cfg)
    for key in (
        "effective_mcc_host_name",
        "effective_hostname",
        "local_hostname",
        "configured_host_name",
    ):
        raw = str(ident.get(key) or "").strip()
        if raw:
            return raw
    return "unknown-host"


def _mysql_conn(cfg: AgentConfig, *, include_database: bool = True) -> pymysql.connections.Connection:
    host = str(getattr(cfg, "state_mysql_host", "") or "").strip()
    password = str(getattr(cfg, "state_mysql_password", "") or "")
    unix_socket = _resolved_mysql_unix_socket(cfg, host=host, password=password)
    kwargs: dict[str, Any] = {
        "user": str(getattr(cfg, "state_mysql_user", "") or "").strip(),
        "password": password,
        "charset": "utf8mb4",
        "autocommit": True,
        "cursorclass": DictCursor,
        "connect_timeout": max(1, int(getattr(cfg, "state_mysql_connect_timeout_sec", 5) or 5)),
        "read_timeout": max(1, int(getattr(cfg, "state_mysql_read_timeout_sec", 15) or 15)),
        "write_timeout": max(1, int(getattr(cfg, "state_mysql_write_timeout_sec", 15) or 15)),
    }
    if unix_socket:
        kwargs["unix_socket"] = unix_socket
    else:
        kwargs["host"] = host
        kwargs["port"] = int(getattr(cfg, "state_mysql_port", 3306) or 3306)
    if include_database:
        kwargs["database"] = _state_database_name(cfg)
    return pymysql.connect(**kwargs)


def _table_names(cfg: AgentConfig) -> tuple[str, str]:
    prefix = _safe_prefix(getattr(cfg, "state_mysql_table_prefix", "mcd_"))
    return f"{prefix}outbound_events", f"{prefix}agent_state_snapshots"


def _schema_key(cfg: AgentConfig) -> str:
    host = str(getattr(cfg, "state_mysql_host", "") or "").strip()
    pwd = str(getattr(cfg, "state_mysql_password", "") or "")
    sock = _resolved_mysql_unix_socket(cfg, host=host, password=pwd)
    return "|".join(
        [
            host,
            str(int(getattr(cfg, "state_mysql_port", 3306) or 3306)),
            str(sock or ""),
            _state_database_name(cfg),
            _safe_prefix(getattr(cfg, "state_mysql_table_prefix", "mcd_")),
        ]
    )


def _db_key(cfg: AgentConfig) -> str:
    host = str(getattr(cfg, "state_mysql_host", "") or "").strip()
    pwd = str(getattr(cfg, "state_mysql_password", "") or "")
    sock = _resolved_mysql_unix_socket(cfg, host=host, password=pwd)
    return "|".join(
        [
            host,
            str(int(getattr(cfg, "state_mysql_port", 3306) or 3306)),
            str(sock or ""),
            _state_database_name(cfg).lower(),
        ]
    )


def _ensure_mysql_database(cfg: AgentConfig) -> None:
    key = _db_key(cfg)
    if key in _DB_READY:
        return
    db_name = _state_database_name(cfg)
    with _mysql_conn(cfg, include_database=False) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME=%s LIMIT 1",
                (db_name,),
            )
            row = cur.fetchone()
            if row is None:
                cur.execute(
                    f"CREATE DATABASE IF NOT EXISTS `{db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
                )
    _DB_READY.add(key)


def _state_db_exists(cfg: AgentConfig) -> bool:
    db_name = _state_database_name(cfg)
    with _mysql_conn(cfg, include_database=False) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME=%s LIMIT 1",
                (db_name,),
            )
            row = cur.fetchone()
            return row is not None


def state_database_exists(cfg: AgentConfig) -> tuple[bool, str]:
    if not mysql_state_enabled(cfg):
        return False, "mysql_state_disabled"
    try:
        return bool(_state_db_exists(cfg)), "ok"
    except Exception as e:
        return False, str(e)


def state_backend_status(cfg: AgentConfig, *, probe: bool = True) -> dict[str, Any]:
    desired = normalized_state_backend(cfg)
    status: dict[str, Any] = {
        "desired_backend": desired,
        "active_backend": "sqlite",
        "mode": "legacy",
        "database": _state_database_name(cfg),
        "reason": "legacy_sqlite_mode",
    }
    if desired != "mysql_hybrid":
        return status
    host = str(getattr(cfg, "state_mysql_host", "") or "").strip()
    user = str(getattr(cfg, "state_mysql_user", "") or "").strip()
    pwd = str(getattr(cfg, "state_mysql_password", "") or "")
    sock = _resolved_mysql_unix_socket(cfg, host=host, password=pwd)
    if not ((host or sock) and user):
        status["reason"] = "mysql_config_missing"
        return status
    if sock:
        status["unix_socket"] = sock
    status["reason"] = "mysql_probe_pending"
    if not probe:
        return status
    existed_before = False
    try:
        existed_before = _state_db_exists(cfg)
    except Exception:
        existed_before = False
    try:
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
        status["active_backend"] = "mysql"
        status["mode"] = "mysql"
        status["reason"] = "ok"
        status["created_now"] = bool(not existed_before)
        return status
    except Exception as e:
        status["reason"] = "mysql_init_failed"
        status["error"] = str(e)
        status["created_now"] = False
        return status


def create_state_database_with_admin(
    cfg: AgentConfig,
    *,
    admin_user: str,
    admin_password: str | None,
    admin_host: str | None = None,
    admin_port: int | None = None,
) -> tuple[bool, str]:
    host = str(admin_host or getattr(cfg, "state_mysql_host", "") or "127.0.0.1").strip()
    port = int(admin_port or getattr(cfg, "state_mysql_port", 3306) or 3306)
    user = str(admin_user or "").strip()
    if not user:
        return False, "admin user is required"

    db_name = _state_database_name(cfg)
    runtime_user = str(getattr(cfg, "state_mysql_user", "") or "").strip()
    runtime_pwd = str(getattr(cfg, "state_mysql_password", "") or "")
    runtime_host = str(getattr(cfg, "state_mysql_host", "") or "").strip()
    runtime_sock = _resolved_mysql_unix_socket(cfg, host=runtime_host, password=runtime_pwd)
    runtime_port = int(getattr(cfg, "state_mysql_port", 3306) or 3306)
    if not runtime_user or not (runtime_host or runtime_sock):
        return False, "state_mysql_user/state_mysql_host (or state_mysql_unix_socket) must be configured first"

    def _esc(v: str) -> str:
        return v.replace("`", "``").replace("'", "''")

    try:
        admin_pwd = str(admin_password or "")
        admin_sock = _resolved_mysql_unix_socket(cfg, host=host, password=admin_pwd)
        admin_kwargs: dict[str, Any] = {
            "user": user,
            "password": admin_pwd,
            "charset": "utf8mb4",
            "autocommit": True,
            "cursorclass": DictCursor,
            "connect_timeout": max(1, int(getattr(cfg, "state_mysql_connect_timeout_sec", 5) or 5)),
            "read_timeout": max(1, int(getattr(cfg, "state_mysql_read_timeout_sec", 15) or 15)),
            "write_timeout": max(1, int(getattr(cfg, "state_mysql_write_timeout_sec", 15) or 15)),
        }
        if admin_sock:
            admin_kwargs["unix_socket"] = admin_sock
        else:
            admin_kwargs["host"] = host
            admin_kwargs["port"] = port
        with pymysql.connect(**admin_kwargs) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"CREATE DATABASE IF NOT EXISTS `{_esc(db_name)}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
                )
                # Grant runtime account access to state DB so agent can switch
                # from legacy sqlite to mysql mode immediately after init.
                for host_pat in ("localhost", "127.0.0.1", "%"):
                    cur.execute(
                        f"GRANT ALL PRIVILEGES ON `{_esc(db_name)}`.* TO '{_esc(runtime_user)}'@'{_esc(host_pat)}'"
                    )
                cur.execute("FLUSH PRIVILEGES")

        # Validate runtime account can use new DB and initialize schema.
        _DB_READY.discard(_db_key(cfg))
        _SCHEMA_READY.discard(_schema_key(cfg))
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn2:
            _ensure_mysql_schema(cfg, conn2)
        return True, f"state database ready: {db_name} (runtime user: {runtime_user})"
    except Exception as e:
        return False, str(e)


def _ensure_mysql_schema(cfg: AgentConfig, conn: pymysql.connections.Connection) -> None:
    key = _schema_key(cfg)
    if key in _SCHEMA_READY:
        return

    events_table, snapshots_table = _table_names(cfg)
    with conn.cursor() as cur:
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS `{events_table}` (
              id BIGINT PRIMARY KEY AUTO_INCREMENT,
              host_name VARCHAR(191) NOT NULL,
              event_id VARCHAR(64) NOT NULL,
              event_type VARCHAR(64) NOT NULL,
              payload_json LONGTEXT NOT NULL,
              status VARCHAR(16) NOT NULL DEFAULT 'pending',
              try_count INT NOT NULL DEFAULT 0,
              last_try_at DOUBLE NULL,
              created_at DOUBLE NOT NULL,
              sent_at DOUBLE NULL,
              last_error TEXT NULL,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              UNIQUE KEY uq_host_event (host_name, event_id),
              KEY idx_host_type_status_created (host_name, event_type, status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """
        )
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS `{snapshots_table}` (
              id BIGINT PRIMARY KEY AUTO_INCREMENT,
              host_name VARCHAR(191) NOT NULL,
              payload_hash VARCHAR(64) NOT NULL,
              payload_json LONGTEXT NOT NULL,
              profile_name VARCHAR(64) NULL,
              instances_count INT NOT NULL DEFAULT 0,
              push_status VARCHAR(32) NULL,
              push_error TEXT NULL,
              created_at DOUBLE NOT NULL,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              UNIQUE KEY uq_host_state (host_name),
              KEY idx_payload_hash (payload_hash)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """
        )
    _SCHEMA_READY.add(key)


def queue_outbound_event_mysql(
    cfg: AgentConfig,
    *,
    event_type: str,
    event_id: str,
    payload_json: str,
    created_at: float,
) -> tuple[bool, str]:
    if not mysql_state_enabled(cfg):
        return False, "mysql_state_disabled"
    host_name = _host_name_for_state(cfg)
    events_table, _ = _table_names(cfg)
    try:
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    INSERT INTO `{events_table}`
                    (host_name, event_id, event_type, payload_json, status, try_count, created_at)
                    VALUES (%s, %s, %s, %s, 'pending', 0, %s)
                    ON DUPLICATE KEY UPDATE
                      event_type=VALUES(event_type),
                      payload_json=VALUES(payload_json),
                      status='pending',
                      last_error=NULL
                    """,
                    (host_name, event_id, event_type, payload_json, float(created_at)),
                )
        return True, "ok"
    except Exception as e:
        return False, str(e)


def read_pending_outbound_event_mysql(cfg: AgentConfig, *, event_type: str) -> tuple[dict[str, Any] | None, str]:
    if not mysql_state_enabled(cfg):
        return None, "mysql_state_disabled"
    host_name = _host_name_for_state(cfg)
    events_table, _ = _table_names(cfg)
    try:
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    SELECT event_id, payload_json
                    FROM `{events_table}`
                    WHERE host_name=%s
                      AND event_type=%s
                      AND status IN ('pending','failed')
                    ORDER BY created_at ASC
                    LIMIT 1
                    """,
                    (host_name, event_type),
                )
                row = cur.fetchone()
        if not isinstance(row, dict):
            return None, "empty"
        payload_json = str(row.get("payload_json") or "")
        try:
            raw = json.loads(payload_json)
        except Exception:
            raw = None
        if not isinstance(raw, dict):
            now_ts = datetime.now(timezone.utc).timestamp()
            with _mysql_conn(cfg) as conn:
                _ensure_mysql_schema(cfg, conn)
                with conn.cursor() as cur:
                    cur.execute(
                        f"""
                        UPDATE `{events_table}`
                        SET status='failed', try_count=try_count+1, last_try_at=%s, last_error=%s
                        WHERE host_name=%s AND event_type=%s AND event_id=%s
                        """,
                        (
                            float(now_ts),
                            "invalid_payload",
                            host_name,
                            event_type,
                            str(row.get("event_id") or ""),
                        ),
                    )
            return None, "invalid_payload"
        return raw, "ok"
    except Exception as e:
        return None, str(e)


def mark_outbound_event_mysql(
    cfg: AgentConfig,
    *,
    event_id: str,
    delivered: bool,
    error: str | None,
) -> tuple[bool, str]:
    if not mysql_state_enabled(cfg):
        return False, "mysql_state_disabled"
    host_name = _host_name_for_state(cfg)
    now_ts = datetime.now(timezone.utc).timestamp()
    events_table, _ = _table_names(cfg)
    try:
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
            with conn.cursor() as cur:
                if delivered:
                    cur.execute(
                        f"""
                        UPDATE `{events_table}`
                        SET status='sent', sent_at=%s, last_try_at=%s, last_error=NULL
                        WHERE host_name=%s AND event_id=%s
                        """,
                        (float(now_ts), float(now_ts), host_name, event_id),
                    )
                else:
                    cur.execute(
                        f"""
                        UPDATE `{events_table}`
                        SET status='failed', try_count=try_count+1, last_try_at=%s, last_error=%s
                        WHERE host_name=%s AND event_id=%s
                        """,
                        (float(now_ts), str(error or "delivery_failed")[:2000], host_name, event_id),
                    )
        return True, "ok"
    except Exception as e:
        return False, str(e)


def prune_outbound_events_mysql(cfg: AgentConfig, *, event_type: str, cutoff_ts: float) -> tuple[int, str]:
    if not mysql_state_enabled(cfg):
        return 0, "mysql_state_disabled"
    host_name = _host_name_for_state(cfg)
    events_table, _ = _table_names(cfg)
    try:
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    DELETE FROM `{events_table}`
                    WHERE host_name=%s
                      AND event_type=%s
                      AND status='sent'
                      AND COALESCE(sent_at, created_at) < %s
                    """,
                    (host_name, event_type, float(cutoff_ts)),
                )
                deleted = int(cur.rowcount or 0)
        return deleted, "ok"
    except Exception as e:
        return 0, str(e)


def upsert_state_snapshot_mysql(
    cfg: AgentConfig,
    *,
    payload: dict[str, Any],
    payload_hash: str,
    created_at: float,
) -> tuple[bool, str]:
    if not mysql_state_enabled(cfg):
        return False, "mysql_state_disabled"
    if not bool(getattr(cfg, "state_mysql_snapshot_enabled", True)):
        return False, "snapshot_disabled"

    host_name = _host_name_for_state(cfg)
    _, snapshots_table = _table_names(cfg)
    try:
        _ensure_mysql_database(cfg)
        safe_payload = _sanitize_snapshot_payload(payload)
        payload_json = json.dumps(safe_payload, ensure_ascii=True, separators=(",", ":"))
        profile_name = str(payload.get("profile") or "").strip().lower() or None
        instances = payload.get("instances")
        instances_count = len(instances) if isinstance(instances, list) else 0
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    INSERT INTO `{snapshots_table}`
                    (host_name, payload_hash, payload_json, profile_name, instances_count, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                      payload_hash=VALUES(payload_hash),
                      payload_json=VALUES(payload_json),
                      profile_name=VALUES(profile_name),
                      instances_count=VALUES(instances_count),
                      created_at=VALUES(created_at),
                      push_status=NULL,
                      push_error=NULL
                    """,
                    (host_name, payload_hash, payload_json, profile_name, int(instances_count), float(created_at)),
                )
        return True, "ok"
    except Exception as e:
        return False, str(e)


def mark_state_snapshot_push_result_mysql(
    cfg: AgentConfig,
    *,
    payload_hash: str,
    delivered: bool,
    message: str,
) -> tuple[bool, str]:
    if not mysql_state_enabled(cfg):
        return False, "mysql_state_disabled"
    if not bool(getattr(cfg, "state_mysql_snapshot_enabled", True)):
        return False, "snapshot_disabled"

    host_name = _host_name_for_state(cfg)
    _, snapshots_table = _table_names(cfg)
    status = "sent" if delivered else "failed"
    try:
        _ensure_mysql_database(cfg)
        with _mysql_conn(cfg) as conn:
            _ensure_mysql_schema(cfg, conn)
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    UPDATE `{snapshots_table}`
                    SET push_status=%s,
                        push_error=%s
                    WHERE host_name=%s AND payload_hash=%s
                    """,
                    (status, None if delivered else str(message or "")[:2000], host_name, payload_hash),
                )
        return True, "ok"
    except Exception as e:
        return False, str(e)
